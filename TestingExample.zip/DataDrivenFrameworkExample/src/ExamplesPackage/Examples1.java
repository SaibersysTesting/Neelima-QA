package ExamplesPackage;

import java.io.File;
import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class Examples1
{
	//addition function
	@Test(dataProvider="testdata")
	public void Addition(String val1,String val2,String val3)
	{
		int a=Integer.parseInt(val1);
		int b=Integer.parseInt(val2);
		int c=Integer.parseInt(val3);
	
		
		int result=a+b+c;
		
		System.out.println(result);
		
	}
	//read the data from excel sheet
	
	@DataProvider(name="testdata")
	public Object[][] ReadExcel() throws BiffException, IOException
	{
		File f=new File("C:\\Users\\mkrishna254\\Documents\\MyBook.xls");
		
		//get the workbook
		Workbook w=Workbook.getWorkbook(f);
		
	//get the sheet
	
	Sheet s=w.getSheet(0);
	
	//get the rows and column number
	int rows=s.getRows();
	
	int columns=s.getColumns();
	
	String inputdata[][]=new String[rows][columns];
	
	//Read the data from excel sheet using row and columns loop
	
	for(int i=0;i<rows;i++)
	{
		for(int j=0;j<columns;j++)
		{
			//get the cell values in sheet
		Cell c=s.getCell(i,j);
		
		inputdata[i][j]=c.getContents();
		
		System.out.println(inputdata[i][j]);
			
		}
	}
	
	return inputdata;
	}
	
	

}
