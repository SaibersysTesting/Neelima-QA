package ExamplesPackage;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class Example3
{
	WebDriver d=new FirefoxDriver();
	
	@Test(dataProvider="geturls")
	public void GetResultdata(String value) throws InterruptedException
	{
		
		 Thread.sleep(2000);
		 d.get(value);
		//System.out.println(value);
	}
	
	//read the excel sheet data
	@DataProvider(name="geturls")
	public Object[][] readExcel() throws BiffException, IOException
	{
		File f=new File("C:\\Users\\mkrishna254\\Desktop\\Data Drivenex2.xlsx");
		
		//get the workbook
		Workbook wb=Workbook.getWorkbook(f);
		
		//get the sheet
		Sheet s=wb.getSheet(0);
		
		int r=s.getRows();
		int c=s.getColumns();
		
		String data[][]=new String[r][c];
		
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++)
			{
				Cell value=s.getCell(i,j);
				
				data[i][j]=value.getContents();
			}
				
		}
		return data;
	}

}
