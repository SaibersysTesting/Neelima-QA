package practise;

public class Sample {

}
