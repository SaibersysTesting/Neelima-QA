package practise;

public class First {
public static void main(String[]argS){
	System.out.println("my first java program");
	
}
}
