

	@Test
    public void test () throws InterruptedException {
    try {
    List<WebElement> no = driver.findElements(By.tagName("a")); 
   int nooflinks = no.size(); 
   System.out.println(nooflinks); 
   for (WebElement pagelink : no) { 
    no.click();
   String linktext = pagelink.getText();
    driver.navigate.refresh();
     Thread.sleep(1000);
   System.out.println(linktext);
      }
    }
   catch (Exception e){
    System.out.println("error "+e);
       }
    } 
}
