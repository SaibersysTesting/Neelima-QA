

	class ForLoop {
		  public static void main(String[] args) {
		    int c;
		 
		    for (c = 1; c <= 10; c++) {
		      System.out.println(c);
		    }
		  }
		}

