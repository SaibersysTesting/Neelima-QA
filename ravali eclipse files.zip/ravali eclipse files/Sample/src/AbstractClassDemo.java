import java.io.*;
public class AbstractClassDemo {
	public static void main(String[]args){
		Bank hdfc = new HDFC();
		hdfc.diposite();
		hdfc.withdraw();
		hdfc.CalculateInterest();
		
		Bank icici = new ICICI();
		icici.diposite();
		icici.withdraw();
		icici.CalculateInterest();
	}
}
abstract class Bank{
	public void diposite(){
		System.out.println("common deposite method implemented across bank");
	}
	public void withdraw(){
		System.out.println("common withdraw method implemented across bank");
	}
	public abstract int CalculateInterest();
}
abstract class HDFC extends Bank{

	public int calculateinterest(){
		System.out.println("Hdfc calculate interest");
		return(0);
	}
}
abstract class ICICI extends Bank{
	public int calculateinterest(){
		System.out.println("ICICI calculate interest");
		return(0);
	}
}





