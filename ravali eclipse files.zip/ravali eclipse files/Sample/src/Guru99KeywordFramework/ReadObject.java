package Guru99KeywordFramework;

public class ReadObject {

}
