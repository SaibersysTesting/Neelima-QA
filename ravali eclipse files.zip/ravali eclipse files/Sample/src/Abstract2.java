

	abstract class Shape
	{
	       void display()
	       {
	       }   
	}

	class Circle extends Shape
	{
	       void display()
	       {
	              System.out.println("You are using circle class");
	       }
	}

	class Rectangle extends Shape
	{
	       void display()
	       {
	              System.out.println("You are using rectangle class");
	       }
	}

	class Triangle extends Shape
	{
	       void display()
	       {
	              System.out.println("You are using triangle class");
	       }
	}

	class AbstractClassDemo
	{
	       public static void main(String args[])
	       {
	               Shape sObj = new Circle();
	               sObj.display();
	               
	               sObj = new Rectangle();
	               sObj.display();

	               sObj = new Triangle();
	               sObj.display();
	       }
	}


	

