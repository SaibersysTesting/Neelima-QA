

	class Programming {
		  //constructor method
		  Programming() {
		    System.out.println("Constructor method called.");
		  }
		 
		  public static void main(String[] args) {
		    Programming object = new Programming(); //creating object
		  }
		}

