
public class Variable2 {
	public static void m1(int x)
	{
		System.out.println("general method");
	}
	public static void m1(int...x){
		System.out.println("var-arg method");
	}
	public static void mian(String[] args){
		m1();
		m1(10,20);
		m1(10,20,30);
		m1(10,20,30,40);
		m1(10);
					
				}
				
	}

