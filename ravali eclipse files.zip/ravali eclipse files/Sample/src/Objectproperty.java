
public class Objectproperty {

}
