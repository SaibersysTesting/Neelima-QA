
public class Test1
{
	 public  static void main(String[]args){
	System.out.println("void main");
}
	 
}
	public class Test2 extends Test1{
		public static void main(String[]args){
			System.out.println("child  main");
		}
	}


