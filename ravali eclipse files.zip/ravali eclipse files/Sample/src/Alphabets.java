

	class Alphabets
	{
	   public static void main(String args[])
	   {
	      char ch;
	 
	      for( ch = 'a' ; ch <= 'z' ; ch++ )
	         System.out.println(ch);
	   }
	}


