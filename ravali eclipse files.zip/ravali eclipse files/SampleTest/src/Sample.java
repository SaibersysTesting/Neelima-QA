class Integers {
  public static void main(String[] arguments) {
    int c; //declaring a variable
 
  /* Using for loop to repeat instruction execution */
 
    for (c = 1; c <= 10; c++) {
      System.out.println(c);
    }
  }
}

	