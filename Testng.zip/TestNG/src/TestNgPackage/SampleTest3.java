package TestNgPackage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class SampleTest3 
{
	WebDriver d=new FirefoxDriver();

	@BeforeMethod
	public void Google() throws InterruptedException
	{
		Thread.sleep(2000);
		d.get("http://www.google.com/");
	}

	@Test(priority=1)
	public void Gmail() throws InterruptedException
	{
		Thread.sleep(2000);
		d.get("http://www.gmail.com/");
	}
	
	@Test(priority=2)
	public void Facebook() throws InterruptedException
	{
		Thread.sleep(2000);
		d.get("http://www.facebook.com/");
	}
	
	@Test(priority=3)
	public void Infibeam() throws InterruptedException
	{
		Thread.sleep(2000);
		d.get("http://www.infibeam.com/");
	}
}
