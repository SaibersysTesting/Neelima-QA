package TestNgPackage;

import org.testng.annotations.Test;

public class SampleTest1
{
	@Test(priority=1)
	public void Login()
	{
		System.out.println("Login successful");
		
	}

	@Test(enabled=false)
	public void BillPayment()
	{
		System.out.println("Bill Payment Successful");
	}
	
	@Test(priority=3)
	public void Logout()
	{
		System.out.println("Log out");
	}
}
